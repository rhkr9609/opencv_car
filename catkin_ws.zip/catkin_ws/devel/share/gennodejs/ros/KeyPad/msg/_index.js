
"use strict";

let where = require('./where.js');

module.exports = {
  where: where,
};
